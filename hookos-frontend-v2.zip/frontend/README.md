# HOOKOS — Frontend

Single-page, framework-free frontend (HTML/CSS/JS). No build step.

```
frontend/
├── index.html         landing + generator, one page
├── styles.css          design tokens, layout, components, animations
├── script.js            nav, framework selector, API calls, loading/results/metrics UI
├── assets/
│   ├── icons/            instagram.svg · youtube.svg · discord.svg
│   ├── images/
│   └── favicon.ico
├── vercel.json
└── README.md
```

## Local development

Serve the folder with any static server, e.g.:

```bash
npx serve frontend
```

`script.js` auto-detects `localhost` and points API calls at `http://localhost:5000`. Update `HOOKOS_CONFIG.API_BASE_URL` at the top of `script.js` once your backend is deployed.

## Deploying to Vercel

1. Push this folder to a repo (or a `frontend/` subfolder of a monorepo).
2. In Vercel: **New Project** → import → set **Root Directory** to wherever this folder lives.
3. No build command needed — it's static.
4. After deploying your backend, update `HOOKOS_CONFIG.API_BASE_URL` in `script.js` and redeploy.

## What this expects from the backend

- `POST /generate` — body `{ idea: string, framework: string }`, returns:
  ```json
  {
    "topic": "string",
    "hook": "string",
    "script": "string",
    "scenePlan": ["string", "..."],
    "cta": "string",
    "framework": "curiosity-gap",
    "metrics": {
      "viralityScore": 0,
      "retentionScore": 0,
      "predictedWatchTime": "string",
      "emotionTrigger": "string",
      "confidence": 0
    }
  }
  ```
- `POST /login`, `POST /logout`, `GET /history` — scaffolded in the UI (profile menu, dropdown, history nav link) but not called until real auth ships.

No AI logic, API keys, or generation logic lives in this folder — everything above is produced by the backend.

## Notes

- Framework values sent to the backend: `curiosity-gap`, `fear`, `contrarian`, `story`, `statistics`, `authority`, `emotion`, `open-loop`.
- Social links in the footer use placeholder URLs — swap them for your real profiles.
- `assets/favicon.ico` and the three icon SVGs are placeholders in the same minimal style as the rest of the UI; replace with final brand assets when ready.
