// ==========================================================================
// HOOKOS — theme toggle (light / dark)
//
// The blocking snippet in <head> already applies the saved theme before
// first paint (see index.html / tool.html) to avoid a flash. This file
// only wires up the toggle button.
// ==========================================================================

(function () {
  'use strict';

  const STORAGE_KEY = 'hookos-theme';

  function getTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch (_) {
      // localStorage unavailable (privacy mode) — theme just won't persist.
    }
    document.querySelectorAll('.theme-toggle').forEach((btn) => {
      btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
    });
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.theme-toggle');
    if (!btn) return;
    setTheme(getTheme() === 'dark' ? 'light' : 'dark');
  });

  document.addEventListener('DOMContentLoaded', () => setTheme(getTheme()));
})();
