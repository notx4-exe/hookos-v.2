// ==========================================================================
// HOOKOS — frontend runtime config
//
// The frontend never talks to any AI provider directly and never holds a
// secret key. It only ever calls our own backend, which is the one place
// API keys live (see /backend/.env).
//
// For local development the backend runs on localhost:5000 by default.
// In production (Vercel), set this to your deployed Render backend URL,
// e.g. https://hookos-api.onrender.com
// ==========================================================================

window.HOOKOS_CONFIG = {
  API_BASE_URL:
    window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
      ? 'http://localhost:5000'
      : 'https://YOUR-BACKEND.onrender.com',
};
