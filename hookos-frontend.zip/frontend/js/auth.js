// ==========================================================================
// HOOKOS — auth stub
//
// No login is implemented yet. This file only prepares the seams:
// - reads a locally cached user (once /login returns one)
// - toggles the navbar between "Login" and a user menu
// - exposes HookosAuth.currentUser() for other scripts (e.g. history)
//
// When Google OAuth ships on the backend, replace `readCachedUser` with a
// real session check (e.g. GET /me) and wire the login button to redirect
// to the backend's OAuth start route.
// ==========================================================================

(function () {
  'use strict';

  const STORAGE_KEY = 'hookos-user';

  function readCachedUser() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }

  function renderAuthUI() {
    const user = readCachedUser();
    const loginEls = document.querySelectorAll('[data-auth-state="signed-out"]');
    const userEls = document.querySelectorAll('[data-auth-state="signed-in"]');

    loginEls.forEach((el) => el.classList.toggle('is-active', !user));
    userEls.forEach((el) => el.classList.toggle('is-active', Boolean(user)));

    if (user) {
      document.querySelectorAll('[data-user-initial]').forEach((el) => {
        el.textContent = (user.name || user.email || '?').trim().charAt(0).toUpperCase();
      });
      document.querySelectorAll('[data-user-name]').forEach((el) => {
        el.textContent = user.name || user.email || 'Account';
      });
    }
  }

  async function handleLogout() {
    try {
      await window.HookosAPI.logout();
    } catch (_) {
      // Best-effort — clear local state regardless.
    }
    window.localStorage.removeItem(STORAGE_KEY);
    renderAuthUI();
  }

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-action="logout"]')) {
      handleLogout();
    }
    if (e.target.closest('[data-action="login"]')) {
      // Placeholder: once the backend exposes Google OAuth, redirect here, e.g.
      // window.location.href = `${window.HOOKOS_CONFIG.API_BASE_URL}/auth/google`;
      console.info('Google Login is not wired up yet.');
    }
  });

  document.addEventListener('DOMContentLoaded', renderAuthUI);

  window.HookosAuth = {
    currentUser: readCachedUser,
    refresh: renderAuthUI,
  };
})();
