// ==========================================================================
// HOOKOS — API client
//
// Thin fetch wrapper around the backend. No AI logic and no secrets live
// here — this file only shapes requests/responses for the UI layer.
// ==========================================================================

(function () {
  'use strict';

  const BASE_URL = (window.HOOKOS_CONFIG && window.HOOKOS_CONFIG.API_BASE_URL) || '';

  async function request(path, options = {}) {
    const res = await fetch(`${BASE_URL}${path}`, {
      credentials: 'include', // sends the auth cookie once Google Login ships
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
      ...options,
    });

    let body = null;
    try {
      body = await res.json();
    } catch (_) {
      // No JSON body — fine for 204s etc.
    }

    if (!res.ok) {
      const message = (body && body.message) || `Request failed with status ${res.status}`;
      const error = new Error(message);
      error.status = res.status;
      error.body = body;
      throw error;
    }

    return body;
  }

  window.HookosAPI = {
    /**
     * Generate a reel blueprint from an idea + style.
     * @param {{ idea: string, style: 'psychology' | 'storytelling' }} payload
     */
    generateBlueprint(payload) {
      return request('/generate', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    },

    /** Fetch the signed-in user's past blueprints. Requires auth once shipped. */
    getHistory() {
      return request('/history', { method: 'GET' });
    },

    /** Placeholder for Google Login — backend will issue a session cookie or JWT. */
    login(credentials) {
      return request('/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      });
    },

    logout() {
      return request('/logout', { method: 'POST' });
    },
  };
})();
