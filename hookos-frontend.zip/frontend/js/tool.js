// ==========================================================================
// HOOKOS — tool page (tool.html)
//
// UI + API calls only. All blueprint generation now happens on the backend
// (POST /generate). This file never contains AI/generation logic itself.
// ==========================================================================

(function () {
  'use strict';

  const form = document.getElementById('blueprint-form');
  if (!form) return; // not on tool.html

  const ideaInput = document.getElementById('idea-input');
  const styleCards = document.querySelectorAll('.style-card');
  const formHint = document.getElementById('form-hint');
  const generateBtn = document.getElementById('generate-btn');
  const generateBtnText = document.getElementById('generate-btn-text');
  const resultsSection = document.getElementById('results');
  const apiError = document.getElementById('api-error');

  let selectedStyle = 'psychology';

  styleCards.forEach((card) => {
    card.addEventListener('click', () => {
      styleCards.forEach((c) => {
        c.classList.remove('selected');
        c.setAttribute('aria-checked', 'false');
      });
      card.classList.add('selected');
      card.setAttribute('aria-checked', 'true');
      selectedStyle = card.dataset.style;
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const idea = ideaInput.value.trim();

    hideError();

    if (!idea) {
      formHint.textContent = 'Enter an idea before generating your blueprint.';
      formHint.classList.add('error');
      ideaInput.focus();
      return;
    }

    formHint.textContent = '';
    formHint.classList.remove('error');
    setLoading(true);

    try {
      const blueprint = await window.HookosAPI.generateBlueprint({
        idea,
        style: selectedStyle,
      });

      renderResults(blueprint);
      resultsSection.hidden = false;
      resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      refreshHistory();
    } catch (err) {
      showError(
        err.status === 429
          ? "You're generating a little too fast — wait a moment and try again."
          : 'Something went wrong generating your blueprint. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  });

  function setLoading(isLoading) {
    generateBtn.disabled = isLoading;
    if (isLoading) {
      generateBtnText.innerHTML =
        'Generating<span class="loading-dots"><span></span><span></span><span></span></span>';
    } else {
      generateBtnText.textContent = 'Generate Blueprint';
    }
  }

  function showError(message) {
    if (!apiError) return;
    apiError.textContent = message;
    apiError.classList.add('is-active');
  }

  function hideError() {
    if (!apiError) return;
    apiError.textContent = '';
    apiError.classList.remove('is-active');
  }

  /* ---------------- Render results ---------------- */

  function renderResults(bp) {
    document.getElementById('result-topic').textContent = bp.topic;
    document.getElementById('result-hook').textContent = bp.hook;
    document.getElementById('result-script').textContent = bp.script;
    document.getElementById('result-cta').textContent = bp.cta;

    const sceneEl = document.getElementById('result-scene');
    sceneEl.innerHTML = '';
    (bp.scenePlan || []).forEach((line, idx) => {
      const row = document.createElement('div');
      row.className = 'scene';
      row.innerHTML = `<span class="scene-num">${idx + 1}.</span><span>${escapeHtml(line)}</span>`;
      sceneEl.appendChild(row);
    });

    document.querySelectorAll('.result-card').forEach((card, i) => {
      card.classList.remove('fade-slide-in');
      void card.offsetWidth; // restart animation on regeneration
      card.style.animationDelay = `${i * 0.06}s`;
      card.classList.add('fade-slide-in');
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  /* ---------------- History (stub — populated once auth ships) ---------------- */

  async function refreshHistory() {
    const panel = document.getElementById('history-list');
    if (!panel || !window.HookosAuth || !window.HookosAuth.currentUser()) return;

    try {
      const history = await window.HookosAPI.getHistory();
      renderHistory(history.items || []);
    } catch (_) {
      // Silently ignore — history is a non-critical enhancement.
    }
  }

  function renderHistory(items) {
    const panel = document.getElementById('history-list');
    if (!panel) return;

    if (!items.length) {
      panel.innerHTML = '<p class="history-empty">Your past blueprints will show up here.</p>';
      return;
    }

    panel.innerHTML = items
      .map(
        (item) => `
        <div class="history-item">
          <span class="history-idea">${escapeHtml(item.idea)}</span>
          <span class="history-meta">${escapeHtml(item.style)} · ${escapeHtml(item.createdAt || '')}</span>
        </div>`
      )
      .join('');
  }

  document.addEventListener('DOMContentLoaded', refreshHistory);

  /* ---------------- Copy buttons ---------------- */

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.copy-btn');
    if (!btn) return;

    const targetId = btn.dataset.target;
    const targetEl = document.getElementById(targetId);
    if (!targetEl) return;

    const text = targetEl.innerText;

    navigator.clipboard
      .writeText(text)
      .then(() => {
        const original = btn.textContent;
        btn.textContent = 'Copied';
        btn.classList.add('copied');
        window.setTimeout(() => {
          btn.textContent = original;
          btn.classList.remove('copied');
        }, 1600);
      })
      .catch(() => {
        btn.textContent = 'Copy failed';
        window.setTimeout(() => {
          btn.textContent = 'Copy';
        }, 1600);
      });
  });
})();
